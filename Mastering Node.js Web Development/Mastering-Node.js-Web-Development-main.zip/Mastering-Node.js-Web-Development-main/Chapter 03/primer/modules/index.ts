export { Name } from "./name";
export { WeatherLocation } from "./weather";

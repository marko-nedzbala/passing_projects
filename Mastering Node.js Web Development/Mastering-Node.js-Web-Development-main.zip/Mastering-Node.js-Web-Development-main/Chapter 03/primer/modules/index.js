"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WeatherLocation = exports.Name = void 0;
var name_1 = require("./name");
Object.defineProperty(exports, "Name", { enumerable: true, get: function () { return name_1.Name; } });
var weather_1 = require("./weather");
Object.defineProperty(exports, "WeatherLocation", { enumerable: true, get: function () { return weather_1.WeatherLocation; } });

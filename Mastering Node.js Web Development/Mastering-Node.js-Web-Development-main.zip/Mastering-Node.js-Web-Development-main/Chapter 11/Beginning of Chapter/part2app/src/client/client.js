document.addEventListener('DOMContentLoaded', () => {
    // do nothing
});

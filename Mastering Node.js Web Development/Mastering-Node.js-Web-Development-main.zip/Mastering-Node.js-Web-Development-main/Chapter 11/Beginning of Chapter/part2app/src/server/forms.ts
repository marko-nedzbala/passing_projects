import { Express } from "express";

export const registerFormMiddleware = (app: Express) => {
    // no middleware yet
}

export const registerFormRoutes = (app: Express) => {
    // no routes yet
}

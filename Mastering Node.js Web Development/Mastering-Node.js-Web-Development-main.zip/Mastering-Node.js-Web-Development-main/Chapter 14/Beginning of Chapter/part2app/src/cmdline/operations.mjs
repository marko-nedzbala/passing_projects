export const ops = {
    "Test": () => {
        console.log("Test operation selected");
    },
    "Exit": () => process.exit()
}

function writeMessage(msg: string) {
    console.log(`Message: ${msg}`);
}

writeMessage("This is the new message");

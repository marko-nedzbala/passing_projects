function writeMessage(msg) {
    console.log("Message: ".concat(msg));
}
writeMessage("This is the new message");

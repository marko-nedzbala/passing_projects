export const Even = (context) => `
    <h4 class="bg-secondary text-white m-2 p-2">
        Even value: ${ context.counter }
    </h4>`

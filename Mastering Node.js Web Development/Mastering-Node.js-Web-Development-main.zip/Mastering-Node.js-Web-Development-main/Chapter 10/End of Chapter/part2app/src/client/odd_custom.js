export const Odd = (context) => `
    <h4 class="bg-primary text-white m-2 p-2">
        Odd value: ${ context.counter }
    </h4>`
